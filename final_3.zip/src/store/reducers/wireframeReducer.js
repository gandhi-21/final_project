const initState = {
    wireframes: []
};

const wireframeReducer = (state = initState, action) => {
    switch(action.type) {
        default:
            return state;
            break;
    }
};

export default wireframeReducer;